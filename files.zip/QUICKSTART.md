# Angus Portal - Quick Start

Get your Angus Energy Benchmarking portal up and running in 5 minutes.

## 🚀 Fastest Path to Demo

```bash
# 1. Install dependencies
npm install

# 2. Run development server
npm run dev

# 3. Open browser
# → http://localhost:3000

# 4. Click "Start Demo"
```

That's it! The app works with mock responses out of the box.

## 📝 Quick Start Instructions

### For Local Development

The portal works immediately without any configuration. Mock AI responses are provided automatically when environment variables are not set.

**Test the features:**
- ✅ Click "Start Demo" to begin a conversation
- ✅ Switch to "Form" tab to enter building details
- ✅ Switch to "Results" tab to see compliance analysis
- ✅ Toggle light/dark theme with the moon/sun button
- ✅ Export your chat history
- ✅ Reset to start fresh

### For Production Deployment

1. **Add OPENAI_API_KEY + ANGUS_WORKFLOW_ID in Vercel**
   - Go to Settings → Environment Variables
   - Add both keys
   - Save and redeploy

2. **Deploy**
   ```bash
   vercel --prod
   ```

3. **Add domain to Agent Builder allowed list**
   - Open your Agent Builder settings
   - Add your Vercel URL to allowed origins
   - Save configuration

4. **Chat with Angus**
   - Visit your deployment URL
   - Start chatting!

## 🎯 Key Features

| Feature | Description |
|---------|-------------|
| **AI Chat** | Conversational interface with markdown support |
| **Smart Form** | Validated building information entry |
| **Results Dashboard** | Detailed compliance analysis |
| **Workflow Stages** | Visual progress through 6 stages |
| **Dark Mode** | Full theme support |
| **Persistent State** | Auto-save to localStorage |
| **Export** | Download chat history |

## 🏗️ Project Structure

```
angus-portal/
├── app/
│   ├── api/angus/route.ts    ← API proxy (with mock fallback)
│   ├── page.tsx              ← Main app component
│   └── layout.tsx            ← Root layout
├── components/
│   ├── Chat.tsx              ← Chat interface
│   ├── Form.tsx              ← Building form
│   ├── Results.tsx           ← Compliance results
│   └── Sidebar.tsx           ← Progress sidebar
├── package.json
├── README.md                 ← Full documentation
└── DEPLOYMENT.md            ← Deployment guide
```

## 🔧 Configuration

### Optional: Connect to Real API

Create `.env.local`:

```env
OPENAI_API_KEY=sk-...
ANGUS_WORKFLOW_ID=wf_...
```

Restart dev server:
```bash
npm run dev
```

## 🎨 Customization

### Change Brand Colors

Edit `tailwind.config.js`:
```javascript
colors: {
  primary: {
    500: '#0ea5e9',  // Change to your brand color
    // ...
  }
}
```

### Update Mock Responses

Edit `app/api/angus/route.ts`:
```typescript
const MOCK_RESPONSES = [
  "Your custom message 1",
  "Your custom message 2",
];
```

### Modify Workflow Stages

Edit `components/Sidebar.tsx`:
```typescript
const stages = [
  { id: 1, name: 'Custom Stage', icon: '🏢' },
  // ...
];
```

## 📱 Browser Support

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)

## 🐛 Troubleshooting

**Problem**: Mock responses in production
- **Solution**: Add environment variables in Vercel, then redeploy

**Problem**: Theme not persisting
- **Solution**: Clear browser cache: `localStorage.clear()`

**Problem**: Build errors
- **Solution**: Delete node_modules and reinstall:
  ```bash
  rm -rf node_modules package-lock.json
  npm install
  ```

## 📚 Documentation

- **README.md** - Complete project documentation
- **DEPLOYMENT.md** - Detailed deployment guide
- **This file** - Quick start instructions

## 💡 Demo Tips

1. **Click "Start Demo"** to auto-start with a pre-filled message
2. **Try the Form tab** to see structured data collection
3. **Check Results tab** after submitting the form
4. **Toggle dark mode** to see theme support
5. **Export chat** to download conversation history

## 🚢 Next Steps

1. **Test locally** with mock data
2. **Deploy to Vercel** for public access
3. **Add real API keys** for production use
4. **Customize branding** to match your style
5. **Add authentication** for multi-user support

## 📞 Support

For questions:
- Check README.md for detailed docs
- Review DEPLOYMENT.md for deployment help
- Check the code comments for implementation details

---

**Ready to go?** Just run `npm install && npm run dev` and visit http://localhost:3000! 🎉
