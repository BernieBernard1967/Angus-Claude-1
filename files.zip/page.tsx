'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from '@/components/Sidebar';
import Chat, { Message } from '@/components/Chat';
import Form, { BuildingFormData } from '@/components/Form';
import Results, { ComplianceResults } from '@/components/Results';

type Tab = 'chat' | 'form' | 'results';

export default function Home() {
  // State management
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  const [currentStage, setCurrentStage] = useState(1);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [ctx, setCtx] = useState<any>({});
  
  const [formData, setFormData] = useState<BuildingFormData>({
    address: '',
    city: '',
    zipCode: '',
    squareFootage: '',
    buildingType: '',
  });

  const [results, setResults] = useState<ComplianceResults | null>(null);

  // Load persisted state from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('angus-theme') as 'light' | 'dark' | null;
    const savedMessages = localStorage.getItem('angus-messages');
    const savedFormData = localStorage.getItem('angus-formData');
    const savedResults = localStorage.getItem('angus-results');
    const savedCtx = localStorage.getItem('angus-ctx');
    const savedStage = localStorage.getItem('angus-stage');

    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    }
    if (savedMessages) {
      const parsed = JSON.parse(savedMessages);
      setMessages(parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })));
    }
    if (savedFormData) {
      setFormData(JSON.parse(savedFormData));
    }
    if (savedResults) {
      setResults(JSON.parse(savedResults));
    }
    if (savedCtx) {
      setCtx(JSON.parse(savedCtx));
    }
    if (savedStage) {
      setCurrentStage(parseInt(savedStage));
    }
  }, []);

  // Persist state to localStorage
  useEffect(() => {
    localStorage.setItem('angus-theme', theme);
    localStorage.setItem('angus-messages', JSON.stringify(messages));
    localStorage.setItem('angus-formData', JSON.stringify(formData));
    localStorage.setItem('angus-results', JSON.stringify(results));
    localStorage.setItem('angus-ctx', JSON.stringify(ctx));
    localStorage.setItem('angus-stage', currentStage.toString());
  }, [theme, messages, formData, results, ctx, currentStage]);

  // Toggle theme
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.classList.toggle('dark');
  };

  // Send message to API
  const sendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/angus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            ...messages.map((m) => ({ role: m.role, content: m.content })),
            { role: 'user', content },
          ],
          ctx,
        }),
      });

      const data = await response.json();

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.assistant,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      setCtx(data.ctx);

      // Advance stage based on conversation progress
      if (messages.length >= 2 && currentStage < 6) {
        setCurrentStage((prev) => Math.min(prev + 1, 6));
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'I apologize, but I encountered an error. Please try again.',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle form submission
  const handleFormSubmit = async () => {
    const formSummary = `I have a building at ${formData.address}, ${formData.city}, CA ${formData.zipCode}. It's ${formData.squareFootage} square feet and used as ${formData.buildingType}. Can you analyze the compliance requirements?`;
    
    await sendMessage(formSummary);
    setActiveTab('chat');
    setCurrentStage(3);

    // Generate mock results for demo
    setTimeout(() => {
      setResults({
        jurisdiction: `City of ${formData.city}`,
        utilities: ['Electricity', 'Natural Gas', 'Water'],
        espmStatus: 'not-registered',
        nextSteps: [
          'Register your property in ENERGY STAR Portfolio Manager',
          'Collect 12 months of utility data',
          'Enter building and energy data into Portfolio Manager',
          'Submit annual benchmarking report to the jurisdiction',
          'Display compliance certificate (if required)',
        ],
        deadlines: [
          { task: 'Annual Report Due', date: 'June 1, 2025' },
          { task: 'Data Entry Completion', date: 'May 1, 2025' },
        ],
        additionalInfo: 'Buildings over 50,000 sq ft must comply annually. First-time compliance may require historical data.',
      });
      setCurrentStage(6);
      setActiveTab('results');
    }, 2000);
  };

  // Start demo
  const startDemo = () => {
    setMessages([]);
    setCtx({});
    setCurrentStage(1);
    setActiveTab('chat');
    
    // Send initial message
    setTimeout(() => {
      sendMessage('Hello, I need help understanding energy benchmarking requirements for my building.');
    }, 500);
  };

  // Reset application
  const resetApp = () => {
    setMessages([]);
    setFormData({
      address: '',
      city: '',
      zipCode: '',
      squareFootage: '',
      buildingType: '',
    });
    setResults(null);
    setCtx({});
    setCurrentStage(1);
    setActiveTab('chat');
    localStorage.clear();
  };

  // Export chat
  const exportChat = () => {
    const chatText = messages
      .map((m) => `[${m.timestamp.toLocaleString()}] ${m.role.toUpperCase()}: ${m.content}`)
      .join('\n\n');
    
    const blob = new Blob([chatText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `angus-chat-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-screen">
      {/* Top Navigation */}
      <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">Angus</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Energy Benchmarking AI</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={startDemo}
              className="px-4 py-2 bg-primary-600 hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600
                       text-white rounded-lg font-medium transition-colors text-sm"
            >
              Start Demo
            </button>
            <button
              onClick={exportChat}
              disabled={messages.length === 0}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700
                       text-gray-700 dark:text-gray-300 rounded-lg font-medium transition-colors text-sm
                       disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Export Chat
            </button>
            <button
              onClick={resetApp}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700
                       text-gray-700 dark:text-gray-300 rounded-lg font-medium transition-colors text-sm"
            >
              Reset
            </button>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700
                       text-gray-700 dark:text-gray-300 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? '🌙' : '☀️'}
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar currentStage={currentStage} />

        {/* Main Content */}
        <main className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-950">
          {/* Tab Navigation */}
          <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
            <nav className="flex gap-1 px-6">
              {(['chat', 'form', 'results'] as Tab[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`
                    px-6 py-3 font-medium text-sm capitalize transition-colors relative
                    ${activeTab === tab
                      ? 'text-primary-600 dark:text-primary-400'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                    }
                  `}
                >
                  {tab}
                  {activeTab === tab && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-600 dark:bg-primary-400"
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                    />
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-hidden">
            <AnimatePresence mode="wait">
              {activeTab === 'chat' && (
                <motion.div
                  key="chat"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="h-full"
                >
                  <Chat
                    messages={messages}
                    onSendMessage={sendMessage}
                    isLoading={isLoading}
                  />
                </motion.div>
              )}

              {activeTab === 'form' && (
                <motion.div
                  key="form"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="h-full overflow-y-auto"
                >
                  <Form
                    formData={formData}
                    onFormChange={setFormData}
                    onSubmit={handleFormSubmit}
                  />
                </motion.div>
              )}

              {activeTab === 'results' && (
                <motion.div
                  key="results"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="h-full"
                >
                  <Results results={results} buildingInfo={formData} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}
