# Angus - Energy Benchmarking Compliance Portal

An AI-powered web portal that helps California building owners comply with energy benchmarking ordinances. Built with Next.js 14, React, TypeScript, and Tailwind CSS.

![Angus Portal](https://img.shields.io/badge/Next.js-14-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-38bdf8?style=flat-square&logo=tailwind-css)

## Features

- 🤖 **AI Chat Interface** - Conversational guidance through compliance requirements
- 📝 **Building Information Form** - Structured data collection
- 📊 **Compliance Results** - Detailed analysis and next steps
- 🌓 **Dark Mode** - Full theme support with persistent preferences
- 💾 **Persistent State** - Chat history and form data saved locally
- 🎨 **Modern UI** - Notion × ChatGPT × Linear inspired design
- 🔄 **Real-time Updates** - Smooth animations with Framer Motion

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Animations**: Framer Motion
- **Markdown**: React Markdown
- **Deployment**: Vercel-ready

## Quick Start

### Local Development

1. **Clone and install dependencies**
   ```bash
   npm install
   ```

2. **Set up environment variables** (optional for demo mode)
   
   Create a `.env.local` file:
   ```env
   OPENAI_API_KEY=your_openai_api_key
   ANGUS_WORKFLOW_ID=your_workflow_id
   ```

   > **Note**: If these variables are not set, the app will use mock responses for local development.

3. **Run the development server**
   ```bash
   npm run dev
   ```

4. **Open the app**
   
   Navigate to [http://localhost:3000](http://localhost:3000)

### Production Deployment (Vercel)

1. **Add environment variables in Vercel**
   - Go to your Vercel project settings
   - Add `OPENAI_API_KEY` and `ANGUS_WORKFLOW_ID`

2. **Deploy**
   ```bash
   vercel --prod
   ```

3. **Configure OpenAI Agent Builder**
   - Add your Vercel domain to the Agent Builder allowed list
   - Test the connection

4. **Chat with Angus**
   - Visit your deployed URL
   - Click "Start Demo" or begin chatting

## Project Structure

```
angus-portal/
├── app/
│   ├── api/
│   │   └── angus/
│   │       └── route.ts          # OpenAI API proxy
│   ├── layout.tsx                # Root layout
│   ├── page.tsx                  # Main application
│   └── globals.css               # Global styles
├── components/
│   ├── Chat.tsx                  # Chat interface
│   ├── Form.tsx                  # Building info form
│   ├── Results.tsx               # Compliance results
│   └── Sidebar.tsx               # Workflow progress
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── next.config.js
```

## API Integration

### OpenAI Responses API

The `/api/angus` route acts as a secure proxy to OpenAI's Responses API:

```typescript
POST /api/angus
Content-Type: application/json

{
  "messages": [
    { "role": "user", "content": "..." }
  ],
  "ctx": { ... }
}

Response:
{
  "assistant": "AI response text",
  "ctx": { ... }
}
```

### Fallback Behavior

If `OPENAI_API_KEY` or `ANGUS_WORKFLOW_ID` are missing, the API returns mock responses, allowing the UI to function for demos and testing.

## Key Features

### 1. Workflow Stages

The sidebar displays 6 stages of the compliance process:
- Building Info
- Jurisdiction Check
- Utility Analysis
- ESPM Verification
- Compliance Review
- Compliance Summary

### 2. Three-Tab Interface

- **Chat**: Conversational AI guidance
- **Form**: Structured building data entry
- **Results**: Detailed compliance analysis

### 3. Persistent State

All data is automatically saved to `localStorage`:
- Chat history
- Form data
- Compliance results
- Theme preference
- Current workflow stage

### 4. Theme Toggle

Switch between light and dark modes with the theme button in the header.

### 5. Export & Reset

- **Export Chat**: Download conversation history as a text file
- **Reset**: Clear all data and start fresh

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `OPENAI_API_KEY` | Your OpenAI API key | No (uses mocks if missing) |
| `ANGUS_WORKFLOW_ID` | Your Agent Builder workflow ID | No (uses mocks if missing) |

## Development

### Build for Production

```bash
npm run build
```

### Run Production Build

```bash
npm start
```

### Type Checking

```bash
npx tsc --noEmit
```

## Customization

### Update Mock Responses

Edit the `MOCK_RESPONSES` array in `app/api/angus/route.ts`:

```typescript
const MOCK_RESPONSES = [
  "Your custom response 1",
  "Your custom response 2",
  // ...
];
```

### Modify Workflow Stages

Edit the `stages` array in `components/Sidebar.tsx`:

```typescript
const stages = [
  { id: 1, name: 'Your Stage', icon: '🏢' },
  // ...
];
```

### Change Theme Colors

Update `tailwind.config.js`:

```javascript
colors: {
  primary: {
    500: '#0ea5e9', // Your brand color
    // ...
  },
}
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)

## Performance

- ⚡ Fast page loads with Next.js optimizations
- 🎨 Smooth 60fps animations
- 📦 Code splitting for optimal bundle size
- 🔄 Automatic prefetching

## Security

- ✅ API key never exposed to client
- ✅ Server-side API proxy
- ✅ Environment variable protection
- ✅ CORS-safe architecture

## Troubleshooting

### API Connection Issues

If you see mock responses in production:
1. Verify environment variables are set in Vercel
2. Check that variable names match exactly
3. Redeploy after adding variables

### Theme Not Persisting

Clear browser cache and localStorage:
```javascript
localStorage.clear();
```

### Build Errors

Ensure all dependencies are installed:
```bash
rm -rf node_modules package-lock.json
npm install
```

## Contributing

This is a demo project for showcasing Angus capabilities. For production use:
1. Implement proper error handling
2. Add user authentication
3. Set up database for persistence
4. Add monitoring and analytics
5. Implement rate limiting

## License

MIT License - feel free to use this as a template for your projects.

## Support

For questions about the OpenAI Responses API, visit [OpenAI Documentation](https://platform.openai.com/docs/).

---

**Built with ❤️ for California building owners**
