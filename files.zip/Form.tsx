'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';

export interface BuildingFormData {
  address: string;
  city: string;
  zipCode: string;
  squareFootage: string;
  buildingType: string;
}

interface FormProps {
  formData: BuildingFormData;
  onFormChange: (data: BuildingFormData) => void;
  onSubmit: () => void;
}

const buildingTypes = [
  'Office',
  'Retail',
  'Multifamily Residential',
  'Hotel',
  'Industrial/Warehouse',
  'Mixed Use',
  'Medical Office',
  'Other',
];

export default function Form({ formData, onFormChange, onSubmit }: FormProps) {
  const [errors, setErrors] = useState<Partial<Record<keyof BuildingFormData, string>>>({});

  const handleChange = (field: keyof BuildingFormData, value: string) => {
    onFormChange({ ...formData, [field]: value });
    // Clear error for this field
    if (errors[field]) {
      setErrors({ ...errors, [field]: undefined });
    }
  };

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof BuildingFormData, string>> = {};

    if (!formData.address.trim()) {
      newErrors.address = 'Address is required';
    }
    if (!formData.city.trim()) {
      newErrors.city = 'City is required';
    }
    if (!formData.zipCode.trim()) {
      newErrors.zipCode = 'ZIP code is required';
    } else if (!/^\d{5}(-\d{4})?$/.test(formData.zipCode)) {
      newErrors.zipCode = 'Invalid ZIP code format';
    }
    if (!formData.squareFootage.trim()) {
      newErrors.squareFootage = 'Square footage is required';
    } else if (isNaN(Number(formData.squareFootage)) || Number(formData.squareFootage) <= 0) {
      newErrors.squareFootage = 'Must be a positive number';
    }
    if (!formData.buildingType) {
      newErrors.buildingType = 'Building type is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-6"
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
          Building Information
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          Provide details about your property to get started with compliance analysis.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Address */}
          <div>
            <label htmlFor="address" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Building Address *
            </label>
            <input
              id="address"
              type="text"
              value={formData.address}
              onChange={(e) => handleChange('address', e.target.value)}
              placeholder="123 Main Street"
              className={`w-full px-4 py-3 rounded-lg border ${
                errors.address 
                  ? 'border-red-500 dark:border-red-500' 
                  : 'border-gray-300 dark:border-gray-700'
              } bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
              focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400`}
            />
            {errors.address && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.address}</p>
            )}
          </div>

          {/* City & ZIP */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="city" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                City *
              </label>
              <input
                id="city"
                type="text"
                value={formData.city}
                onChange={(e) => handleChange('city', e.target.value)}
                placeholder="San Francisco"
                className={`w-full px-4 py-3 rounded-lg border ${
                  errors.city 
                    ? 'border-red-500 dark:border-red-500' 
                    : 'border-gray-300 dark:border-gray-700'
                } bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
                focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400`}
              />
              {errors.city && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.city}</p>
              )}
            </div>

            <div>
              <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                ZIP Code *
              </label>
              <input
                id="zipCode"
                type="text"
                value={formData.zipCode}
                onChange={(e) => handleChange('zipCode', e.target.value)}
                placeholder="94102"
                className={`w-full px-4 py-3 rounded-lg border ${
                  errors.zipCode 
                    ? 'border-red-500 dark:border-red-500' 
                    : 'border-gray-300 dark:border-gray-700'
                } bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
                focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400`}
              />
              {errors.zipCode && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.zipCode}</p>
              )}
            </div>
          </div>

          {/* Square Footage */}
          <div>
            <label htmlFor="squareFootage" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Square Footage *
            </label>
            <input
              id="squareFootage"
              type="text"
              value={formData.squareFootage}
              onChange={(e) => handleChange('squareFootage', e.target.value)}
              placeholder="50000"
              className={`w-full px-4 py-3 rounded-lg border ${
                errors.squareFootage 
                  ? 'border-red-500 dark:border-red-500' 
                  : 'border-gray-300 dark:border-gray-700'
              } bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
              focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400`}
            />
            {errors.squareFootage && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.squareFootage}</p>
            )}
          </div>

          {/* Building Type */}
          <div>
            <label htmlFor="buildingType" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Building Type *
            </label>
            <select
              id="buildingType"
              value={formData.buildingType}
              onChange={(e) => handleChange('buildingType', e.target.value)}
              className={`w-full px-4 py-3 rounded-lg border ${
                errors.buildingType 
                  ? 'border-red-500 dark:border-red-500' 
                  : 'border-gray-300 dark:border-gray-700'
              } bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100
              focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400`}
            >
              <option value="">Select a building type</option>
              {buildingTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
            {errors.buildingType && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.buildingType}</p>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full px-6 py-3 bg-primary-600 hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600
                     text-white rounded-lg font-medium transition-colors
                     focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
          >
            Analyze Building Compliance
          </button>
        </form>
      </div>
    </motion.div>
  );
}
