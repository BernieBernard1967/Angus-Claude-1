# Deployment Guide

This guide walks you through deploying Angus to Vercel and connecting it to your OpenAI Agent Builder workflow.

## Prerequisites

- Vercel account (free tier works)
- OpenAI API key
- Agent Builder workflow ID
- Git repository (GitHub, GitLab, or Bitbucket)

## Step-by-Step Deployment

### 1. Prepare Your Repository

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: Angus portal"

# Add your remote repository
git remote add origin <your-repo-url>

# Push to main branch
git push -u origin main
```

### 2. Deploy to Vercel

#### Option A: Using Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# When prompted:
# - Link to existing project? No
# - What's your project's name? angus-portal
# - In which directory is your code located? ./
# - Override settings? No
```

#### Option B: Using Vercel Dashboard

1. Go to [vercel.com](https://vercel.com)
2. Click "Add New" → "Project"
3. Import your Git repository
4. Configure:
   - **Framework Preset**: Next.js
   - **Root Directory**: ./
   - **Build Command**: `npm run build`
   - **Output Directory**: .next
5. Click "Deploy"

### 3. Add Environment Variables

After initial deployment:

1. Go to your project in Vercel dashboard
2. Navigate to **Settings** → **Environment Variables**
3. Add the following variables:

   | Name | Value | Environment |
   |------|-------|-------------|
   | `OPENAI_API_KEY` | Your OpenAI API key | Production, Preview, Development |
   | `ANGUS_WORKFLOW_ID` | Your workflow ID | Production, Preview, Development |

4. Click "Save"

### 4. Redeploy with Environment Variables

```bash
# Using CLI
vercel --prod

# Or trigger redeployment from Vercel dashboard
# Go to Deployments → Click "..." → Redeploy
```

### 5. Configure OpenAI Agent Builder

1. Open your Agent Builder dashboard
2. Navigate to your workflow settings
3. Add your Vercel domain to the **Allowed Origins** list:
   ```
   https://your-project.vercel.app
   ```
4. Save the configuration

### 6. Test the Connection

1. Visit your deployed URL: `https://your-project.vercel.app`
2. Click "Start Demo"
3. Send a test message
4. Verify you receive responses from your Agent Builder workflow

## Custom Domain Setup (Optional)

### Add a Custom Domain

1. In Vercel dashboard, go to **Settings** → **Domains**
2. Click "Add" and enter your domain
3. Follow DNS configuration instructions
4. Wait for DNS propagation (can take up to 48 hours)

### Update Agent Builder Allowed Origins

Don't forget to add your custom domain to Agent Builder:
```
https://yourdomain.com
```

## Environment-Specific Configuration

### Production

For production deployments:
- Always set environment variables
- Enable error tracking (Sentry, LogRocket, etc.)
- Set up analytics (Google Analytics, Mixpanel, etc.)
- Configure proper CORS policies

### Preview (Staging)

For preview deployments:
- Use separate test API keys
- Create a test workflow in Agent Builder
- Test new features before production

### Development

For local development:
- Create `.env.local` file
- Use development API keys
- Enable verbose logging

## Monitoring and Maintenance

### Check Deployment Logs

```bash
# View deployment logs
vercel logs <deployment-url>

# Stream production logs
vercel logs --follow
```

### Performance Monitoring

Vercel automatically provides:
- Web Vitals metrics
- Function execution logs
- Build time analytics

Access these in your Vercel dashboard under **Analytics**.

### Update Dependencies

```bash
# Check for updates
npm outdated

# Update packages
npm update

# Or use npm-check-updates
npx npm-check-updates -u
npm install
```

## Troubleshooting

### API Connection Fails

**Symptoms**: Mock responses appear in production

**Solutions**:
1. Verify environment variables are set correctly
2. Check variable names match exactly (case-sensitive)
3. Ensure workflow ID is valid
4. Verify API key has correct permissions
5. Check Agent Builder allowed origins includes your domain

### Build Failures

**Symptoms**: Deployment fails during build

**Solutions**:
```bash
# Test build locally
npm run build

# Check for TypeScript errors
npx tsc --noEmit

# Verify all dependencies are listed
npm install
```

### CORS Errors

**Symptoms**: Browser console shows CORS errors

**Solutions**:
1. Add your domain to Agent Builder allowed origins
2. Wait a few minutes for changes to propagate
3. Clear browser cache
4. Test in incognito mode

### Performance Issues

**Symptoms**: Slow page loads

**Solutions**:
1. Enable Vercel Edge Functions (in vercel.json)
2. Optimize images with Next.js Image component
3. Implement code splitting
4. Enable caching headers

## Scaling Considerations

### High Traffic

For applications expecting high traffic:

1. **Enable Edge Functions**
   ```json
   // vercel.json
   {
     "functions": {
       "app/api/angus/route.ts": {
         "runtime": "edge"
       }
     }
   }
   ```

2. **Implement Rate Limiting**
   - Add rate limiting middleware
   - Use Vercel's built-in rate limiting
   - Consider Redis for distributed rate limiting

3. **Add Caching**
   ```typescript
   // In API route
   export const runtime = 'edge';
   export const revalidate = 60; // Cache for 60 seconds
   ```

### Database Integration

For production persistence:

1. Choose a database (Vercel Postgres, Supabase, etc.)
2. Update data persistence logic
3. Migrate localStorage data to database
4. Implement user authentication

## Security Best Practices

1. **Never commit `.env` files**
   ```bash
   # Always in .gitignore
   .env*.local
   .env
   ```

2. **Rotate API keys regularly**
   - Update in Vercel dashboard
   - Update in Agent Builder
   - Redeploy

3. **Implement authentication**
   - Use NextAuth.js
   - Add protected API routes
   - Implement user sessions

4. **Enable security headers**
   ```javascript
   // next.config.js
   module.exports = {
     async headers() {
       return [
         {
           source: '/:path*',
           headers: [
             {
               key: 'X-Frame-Options',
               value: 'DENY',
             },
             {
               key: 'X-Content-Type-Options',
               value: 'nosniff',
             },
           ],
         },
       ];
     },
   };
   ```

## Rollback Procedure

If you need to rollback to a previous version:

1. Go to Vercel dashboard → **Deployments**
2. Find the working deployment
3. Click "..." → **Promote to Production**

Or using CLI:
```bash
vercel rollback <deployment-url>
```

## Cost Optimization

Vercel free tier includes:
- 100GB bandwidth/month
- 100 serverless function executions/day
- Unlimited preview deployments

For higher limits:
- Monitor usage in Vercel dashboard
- Upgrade to Pro plan if needed ($20/month)
- Optimize function execution time
- Implement caching strategies

## Support Resources

- **Vercel Documentation**: https://vercel.com/docs
- **Next.js Documentation**: https://nextjs.org/docs
- **OpenAI API Documentation**: https://platform.openai.com/docs
- **Vercel Community**: https://github.com/vercel/vercel/discussions

## Quick Reference

```bash
# Deploy to production
vercel --prod

# View logs
vercel logs --follow

# List deployments
vercel ls

# Add domain
vercel domains add <domain>

# Set environment variable
vercel env add OPENAI_API_KEY

# Pull environment variables locally
vercel env pull
```

---

**Need help?** Create an issue in the repository or contact the development team.
