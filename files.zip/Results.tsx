'use client';

import { motion } from 'framer-motion';

export interface ComplianceResults {
  jurisdiction: string;
  utilities: string[];
  espmStatus: 'registered' | 'not-registered' | 'unknown';
  nextSteps: string[];
  deadlines: { task: string; date: string }[];
  additionalInfo?: string;
}

interface ResultsProps {
  results: ComplianceResults | null;
  buildingInfo?: {
    address: string;
    city: string;
    zipCode: string;
    squareFootage: string;
    buildingType: string;
  };
}

export default function Results({ results, buildingInfo }: ResultsProps) {
  if (!results) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">📊</span>
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            No Results Yet
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Complete the building form or chat with Angus to see your compliance analysis.
          </p>
        </div>
      </div>
    );
  }

  const statusColors = {
    'registered': 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300',
    'not-registered': 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300',
    'unknown': 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-300',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-6 overflow-y-auto h-full"
    >
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
            Compliance Analysis Results
          </h2>
          {buildingInfo && (
            <p className="text-gray-600 dark:text-gray-400">
              {buildingInfo.address}, {buildingInfo.city}, CA {buildingInfo.zipCode}
            </p>
          )}
        </div>

        {/* Jurisdiction */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-xl">📍</span>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
                Jurisdiction
              </h3>
              <p className="text-gray-700 dark:text-gray-300">{results.jurisdiction}</p>
            </div>
          </div>
        </div>

        {/* Utilities */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-xl">⚡</span>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                Required Utilities
              </h3>
              <div className="flex flex-wrap gap-2">
                {results.utilities.map((utility, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300 
                             rounded-full text-sm font-medium"
                  >
                    {utility}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ESPM Status */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-xl">✓</span>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                ENERGY STAR Portfolio Manager Status
              </h3>
              <span className={`inline-block px-4 py-2 rounded-lg font-medium ${statusColors[results.espmStatus]}`}>
                {results.espmStatus === 'registered' && 'Registered ✓'}
                {results.espmStatus === 'not-registered' && 'Not Registered'}
                {results.espmStatus === 'unknown' && 'Status Unknown'}
              </span>
            </div>
          </div>
        </div>

        {/* Next Steps */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-xl">📋</span>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                Next Steps
              </h3>
              <ol className="space-y-2">
                {results.nextSteps.map((step, index) => (
                  <li key={index} className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 
                                   rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </span>
                    <span className="text-gray-700 dark:text-gray-300 pt-0.5">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        {/* Deadlines */}
        {results.deadlines && results.deadlines.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-xl">📅</span>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                  Important Deadlines
                </h3>
                <div className="space-y-3">
                  {results.deadlines.map((deadline, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                      <span className="text-gray-700 dark:text-gray-300">{deadline.task}</span>
                      <span className="text-sm font-medium text-primary-600 dark:text-primary-400">
                        {deadline.date}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Additional Info */}
        {results.additionalInfo && (
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <p className="text-sm text-blue-900 dark:text-blue-200">
              <strong>Note:</strong> {results.additionalInfo}
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
