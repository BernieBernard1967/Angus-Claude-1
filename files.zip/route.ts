import { NextRequest, NextResponse } from 'next/server';

// Mock responses for local development when env vars are missing
const MOCK_RESPONSES = [
  "Hello! I'm Angus, your AI assistant for California energy benchmarking compliance. I help building owners understand and meet their local ordinance requirements. Could you tell me a bit about your building? The address would be a great place to start.",
  "Thank you for that information. Based on what you've shared, I can help you determine which benchmarking ordinances apply to your property. Let me analyze your building details and jurisdictional requirements.",
  "Great! I've identified the relevant compliance requirements for your building. Your property falls under the jurisdiction's energy benchmarking ordinance. Let me walk you through the next steps to ensure full compliance.",
];

let mockIndex = 0;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { messages, ctx } = body;

    // Check if we have the required environment variables
    const apiKey = process.env.OPENAI_API_KEY;
    const workflowId = process.env.ANGUS_WORKFLOW_ID;

    // If env vars are missing, return mock response
    if (!apiKey || !workflowId) {
      console.log('⚠️  Missing env vars - using mock response');
      
      const mockResponse = MOCK_RESPONSES[mockIndex % MOCK_RESPONSES.length];
      mockIndex++;

      return NextResponse.json({
        assistant: mockResponse,
        ctx: {
          ...ctx,
          mock: true,
          timestamp: new Date().toISOString(),
        },
      });
    }

    // Make real API call to OpenAI Responses API
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'OpenAI-Beta': 'responses=v2',
      },
      body: JSON.stringify({
        workflow_id: workflowId,
        model: 'gpt-4.1',
        messages: messages,
        input: {
          ctx: ctx || {},
        },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API Error:', errorText);
      
      // Fallback to mock on API error
      const mockResponse = MOCK_RESPONSES[mockIndex % MOCK_RESPONSES.length];
      mockIndex++;
      
      return NextResponse.json({
        assistant: mockResponse,
        ctx: {
          ...ctx,
          error: 'API call failed, using mock response',
          timestamp: new Date().toISOString(),
        },
      });
    }

    const data = await response.json();

    // Extract assistant message and context from OpenAI response
    const assistantMessage = data.choices?.[0]?.message?.content || data.output || 'I apologize, but I encountered an issue. Could you please try again?';
    const updatedCtx = data.output_ctx || ctx;

    return NextResponse.json({
      assistant: assistantMessage,
      ctx: updatedCtx,
    });

  } catch (error) {
    console.error('API route error:', error);
    
    // Return mock response on any error
    const mockResponse = MOCK_RESPONSES[mockIndex % MOCK_RESPONSES.length];
    mockIndex++;
    
    return NextResponse.json({
      assistant: mockResponse,
      ctx: {
        error: 'Unexpected error occurred',
        timestamp: new Date().toISOString(),
      },
    });
  }
}
