# Angus Portal - Application Structure

## Visual Component Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│  app/layout.tsx (Root Layout)                               │
│  ├── Global fonts (Inter)                                   │
│  ├── Metadata (title, description)                          │
│  └── Dark mode support                                      │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  app/page.tsx (Main Application)                            │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Header (Navigation Bar)                               │ │
│  │  ├── Logo + Brand                                      │ │
│  │  ├── Start Demo button                                 │ │
│  │  ├── Export Chat button                                │ │
│  │  ├── Reset button                                      │ │
│  │  └── Theme toggle (light/dark)                         │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────┬────────────────────────────────────────────┐ │
│  │            │                                            │ │
│  │  Sidebar   │  Main Content Area                        │ │
│  │            │                                            │ │
│  │  Stage 1 ✓ │  ┌──────────────────────────────────────┐ │ │
│  │  Stage 2 ✓ │  │  Tab Navigation                      │ │ │
│  │  Stage 3 ● │  │  [Chat] [Form] [Results]             │ │ │
│  │  Stage 4   │  └──────────────────────────────────────┘ │ │
│  │  Stage 5   │                                            │ │
│  │  Stage 6   │  ┌──────────────────────────────────────┐ │ │
│  │            │  │                                      │ │ │
│  │  Progress  │  │  Active Tab Content:                 │ │ │
│  │  3 of 6    │  │                                      │ │ │
│  │            │  │  • Chat.tsx (messages + input)       │ │ │
│  │            │  │  • Form.tsx (building details)       │ │ │
│  │            │  │  • Results.tsx (compliance data)     │ │ │
│  │            │  │                                      │ │ │
│  │            │  └──────────────────────────────────────┘ │ │
│  └────────────┴────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Component Breakdown

### 1. Sidebar Component
```
components/Sidebar.tsx
├── Props: currentStage (number)
├── Displays 6 workflow stages
├── Visual indicators:
│   ├── ✓ Completed stages (green)
│   ├── ● Current stage (blue)
│   └── ○ Future stages (gray)
└── Progress counter at bottom
```

### 2. Chat Component
```
components/Chat.tsx
├── Props: messages[], onSendMessage(), isLoading
├── Message list (scrollable)
│   ├── User messages (right, blue)
│   ├── Assistant messages (left, white/gray)
│   ├── Markdown rendering
│   └── Timestamps
├── Loading indicator (animated dots)
└── Input area
    ├── Text input field
    └── Send button
```

### 3. Form Component
```
components/Form.tsx
├── Props: formData, onFormChange(), onSubmit()
├── Fields:
│   ├── Address (text)
│   ├── City (text)
│   ├── ZIP Code (text, validated)
│   ├── Square Footage (number, validated)
│   └── Building Type (select dropdown)
├── Validation:
│   ├── Required field checks
│   ├── ZIP code format
│   └── Number validation
└── Submit button
```

### 4. Results Component
```
components/Results.tsx
├── Props: results, buildingInfo
├── Displays:
│   ├── Jurisdiction card (with icon)
│   ├── Required utilities (chips)
│   ├── ESPM status (badge)
│   ├── Next steps (numbered list)
│   ├── Deadlines (date cards)
│   └── Additional info (note box)
└── Empty state when no results
```

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  User Interaction                                           │
└───────────────────┬─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────┐
│  app/page.tsx (State Management)                            │
│  ├── messages: Message[]                                    │
│  ├── formData: BuildingFormData                             │
│  ├── results: ComplianceResults                             │
│  ├── ctx: any (API context)                                 │
│  ├── currentStage: number                                   │
│  └── theme: 'light' | 'dark'                                │
└───────────────────┬─────────────────────────────────────────┘
                    │
        ┌───────────┴───────────┐
        │                       │
        ▼                       ▼
┌──────────────┐       ┌──────────────────┐
│ localStorage │       │  API Route       │
│              │       │  /api/angus      │
│ Persists:    │       │                  │
│ • Messages   │       │  If env vars:    │
│ • Form data  │       │  ├─→ OpenAI API  │
│ • Results    │       │  │               │
│ • Theme      │       │  Else:           │
│ • Stage      │       │  └─→ Mock data   │
└──────────────┘       └──────────────────┘
```

## API Request Flow

```
User sends message
        │
        ▼
┌─────────────────────────────────────┐
│  app/page.tsx                       │
│  sendMessage(content)               │
└─────────────────┬───────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│  POST /api/angus                    │
│  Body: { messages, ctx }            │
└─────────────────┬───────────────────┘
                  │
        ┌─────────┴─────────┐
        │                   │
        ▼                   ▼
┌──────────────┐   ┌──────────────────┐
│  Has env     │   │  No env vars     │
│  vars?       │   │                  │
│              │   │  Return mock     │
│  POST to     │   │  response        │
│  OpenAI API  │   │                  │
└──────┬───────┘   └─────────┬────────┘
       │                     │
       └─────────┬───────────┘
                 ▼
┌─────────────────────────────────────┐
│  Response                           │
│  { assistant: string, ctx: any }    │
└─────────────────┬───────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│  app/page.tsx                       │
│  ├─ Add assistant message           │
│  ├─ Update ctx                      │
│  ├─ Advance stage                   │
│  └─ Persist to localStorage         │
└─────────────────────────────────────┘
```

## State Persistence Flow

```
┌─────────────────────────────────────────────────────┐
│  On Component Mount (useEffect)                     │
│  └─→ Read from localStorage                         │
│      ├─ angus-theme                                 │
│      ├─ angus-messages                              │
│      ├─ angus-formData                              │
│      ├─ angus-results                               │
│      ├─ angus-ctx                                   │
│      └─ angus-stage                                 │
└─────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────┐
│  On State Change (useEffect)                        │
│  └─→ Write to localStorage                          │
│      ├─ Automatic save                              │
│      ├─ No manual triggers                          │
│      └─ Immediate persistence                       │
└─────────────────────────────────────────────────────┘
```

## Theme System

```
┌─────────────────────────────────────────┐
│  Theme Toggle Button                    │
│  (in Header)                            │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│  toggleTheme()                          │
│  ├─ Update state: theme                │
│  ├─ Toggle .dark class on <html>       │
│  └─ Save to localStorage                │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│  Tailwind CSS                           │
│  Applies dark: variants                 │
│  ├─ dark:bg-gray-900                    │
│  ├─ dark:text-gray-100                  │
│  └─ dark:border-gray-800                │
└─────────────────────────────────────────┘
```

## File Dependencies

```
app/page.tsx
├── components/Sidebar.tsx
├── components/Chat.tsx
│   └── react-markdown
├── components/Form.tsx
└── components/Results.tsx

app/api/angus/route.ts
└── (no dependencies - standalone)

All components
├── framer-motion (animations)
├── React (hooks, state)
└── Tailwind CSS (styling)
```

## Key TypeScript Interfaces

```typescript
// Message structure
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// Form data structure
interface BuildingFormData {
  address: string;
  city: string;
  zipCode: string;
  squareFootage: string;
  buildingType: string;
}

// Results structure
interface ComplianceResults {
  jurisdiction: string;
  utilities: string[];
  espmStatus: 'registered' | 'not-registered' | 'unknown';
  nextSteps: string[];
  deadlines: { task: string; date: string }[];
  additionalInfo?: string;
}
```

## Styling Architecture

```
Global Styles (app/globals.css)
├── Tailwind base, components, utilities
├── Custom scrollbar styles
├── Dark mode variables
└── Base body styles

Tailwind Config (tailwind.config.js)
├── Dark mode: 'class'
├── Custom colors (primary palette)
├── Custom animations
│   ├── slide-up
│   └── fade-in
└── Content paths

Component Styles
├── Utility classes (Tailwind)
├── Conditional classes (template literals)
├── Motion components (Framer Motion)
└── Responsive breakpoints
```

## Animation System

```
Framer Motion Animations

Page transitions:
├── Tab switching (left/right slide)
├── Component mounting (fade + slide up)
└── Layout animations (smooth)

Message bubbles:
├── Fade in on appear
├── Slide up 10px
└── Stagger children

Loading indicator:
├── Scale animation (1 → 1.2 → 1)
├── Stagger timing (0s, 0.2s, 0.4s)
└── Infinite repeat

Sidebar stages:
├── Individual delays (stage × 0.1s)
├── Current stage border (layoutId)
└── Spring transition
```

## Build Process

```
Development
├── next dev
├── Port 3000
├── Fast refresh
└── TypeScript checking

Production
├── next build
├── Static optimization
├── Code splitting
├── Image optimization
└── Bundle analysis

Deployment
├── Vercel (recommended)
├── Environment variables
├── Edge functions
└── Automatic SSL
```

---

This structure enables:
✅ Clean separation of concerns
✅ Reusable components
✅ Type safety throughout
✅ Easy maintenance
✅ Scalable architecture
