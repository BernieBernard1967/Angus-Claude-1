'use client';

import { motion } from 'framer-motion';

interface SidebarProps {
  currentStage: number;
}

const stages = [
  { id: 1, name: 'Building Info', icon: '🏢' },
  { id: 2, name: 'Jurisdiction Check', icon: '📍' },
  { id: 3, name: 'Utility Analysis', icon: '⚡' },
  { id: 4, name: 'ESPM Verification', icon: '✓' },
  { id: 5, name: 'Compliance Review', icon: '📋' },
  { id: 6, name: 'Compliance Summary', icon: '📊' },
];

export default function Sidebar({ currentStage }: SidebarProps) {
  return (
    <aside className="w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 p-6 flex flex-col">
      <div className="mb-8">
        <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">
          Workflow Progress
        </h2>
      </div>

      <nav className="space-y-2 flex-1">
        {stages.map((stage) => {
          const isCompleted = stage.id < currentStage;
          const isCurrent = stage.id === currentStage;

          return (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: stage.id * 0.1 }}
              className={`
                relative flex items-center gap-3 px-4 py-3 rounded-lg transition-all
                ${isCurrent 
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300 font-medium' 
                  : isCompleted
                  ? 'text-gray-700 dark:text-gray-300'
                  : 'text-gray-400 dark:text-gray-600'
                }
              `}
            >
              <div className={`
                flex items-center justify-center w-8 h-8 rounded-full text-sm
                ${isCompleted 
                  ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' 
                  : isCurrent
                  ? 'bg-primary-100 dark:bg-primary-800/30 text-primary-600 dark:text-primary-400'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-600'
                }
              `}>
                {isCompleted ? '✓' : stage.icon}
              </div>
              
              <span className="text-sm">{stage.name}</span>

              {isCurrent && (
                <motion.div
                  layoutId="currentStage"
                  className="absolute inset-0 border-2 border-primary-500 dark:border-primary-400 rounded-lg"
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
              )}
            </motion.div>
          );
        })}
      </nav>

      <div className="mt-auto pt-6 border-t border-gray-200 dark:border-gray-800">
        <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
          Stage {currentStage} of {stages.length}
        </p>
      </div>
    </aside>
  );
}
